#pragma once

int cuda_test();
